**DEPRECATED**

This folder and its files may be deleted in future.

The contained files were copied to:
[LibreCAD-ROOT]/desktop/media/logo

Please use these files from their new location.

This folder contains svg icons colored in default LC icons scheme. It uses the following colors:

#000 - black - main color
#00ff7f - green - accent color 
#fff - black - white color

In general, they might be used as basis for creation of alternative user-defined icons set.
